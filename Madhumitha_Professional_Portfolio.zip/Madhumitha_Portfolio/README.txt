MADHUMITHA - PROFESSIONAL PORTFOLIO
===================================

CONTENTS
- index.html: portfolio webpage
- style.css: responsive visual styling
- script.js: mobile navigation and current year
- assets/: original uploaded PDFs and CSV

HOW TO VIEW
1. Extract the ZIP file.
2. Open the Madhumitha_Portfolio folder.
3. Double-click index.html to open the portfolio in a browser.
4. Internet access is needed for the optional Google Fonts; the site otherwise works locally.

BEFORE PUBLISHING
- Replace the sample email address (your.email@example.com) in index.html.
- Add your confirmed education details, skills, project descriptions, profile photo and any additional contact/social links.
- Check that all personal details are correct before making the website public.

DOCUMENT ACCURACY
- The Infosys PDF is listed as a course completion certificate.
- The Power BI PDF is an attendance record for the workshop, not represented as an individual completion certificate.
- The CSV is described only by its visible structure (418 rows, PassengerId and Survived); no analysis results are claimed.

To publish, upload the extracted folder contents to a static hosting service such as GitHub Pages or Netlify.
